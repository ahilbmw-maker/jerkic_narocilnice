// ─── STATE ───────────────────────────────────────────────
let currentView = 'dashboard';
let searchTimeout = null;

// ─── NAVIGATION ──────────────────────────────────────────
function navigate(view) {
  document.querySelectorAll('.view').forEach(v => v.classList.remove('active'));
  document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active'));
  document.getElementById('view-' + view).classList.add('active');
  document.querySelector(`[data-view="${view}"]`).classList.add('active');
  currentView = view;
  renderView(view);
}

function renderView(view) {
  switch(view) {
    case 'dashboard': renderDashboard(); break;
    case 'narocilnice': renderListView('narocilnica'); break;
    case 'ponudbe': renderListView('ponudba'); break;
    case 'stranke': renderStranke(); break;
  }
}

// ─── API HELPERS ─────────────────────────────────────────
async function api(method, path, body) {
  const opts = { method, headers: { 'Content-Type': 'application/json' } };
  if (body) opts.body = JSON.stringify(body);
  const r = await fetch('/api' + path, opts);
  if (r.status === 401) { location.href = '/login'; return; }
  return r.json();
}
const GET = p => api('GET', p);
const POST = (p, b) => api('POST', p, b);
const PUT = (p, b) => api('PUT', p, b);
const DEL = p => api('DELETE', p);

// ─── TOAST ───────────────────────────────────────────────
let toastTimer;
function toast(msg, type = '') {
  const el = document.getElementById('toast');
  el.textContent = msg;
  el.className = 'toast' + (type ? ' ' + type : '');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => el.classList.add('hidden'), 3000);
}

// ─── MODAL ───────────────────────────────────────────────
function openModal(html, wide = false) {
  document.getElementById('modal-content').innerHTML = html;
  const box = document.getElementById('modal-box');
  box.className = 'modal-box' + (wide ? ' wide' : '');
  document.getElementById('modal-overlay').classList.remove('hidden');
}
function closeModal(e) {
  if (!e || e.target === document.getElementById('modal-overlay')) {
    document.getElementById('modal-overlay').classList.add('hidden');
  }
}

// ─── FORMAT HELPERS ──────────────────────────────────────
function fmtDate(d) {
  if (!d) return '—';
  return new Date(d).toLocaleDateString('sl-SI');
}
function fmtEur(n) {
  return (parseFloat(n) || 0).toFixed(2) + ' €';
}
function statusBadge(status) {
  return `<span class="badge badge-${status}">${statusLabel(status)}</span>`;
}
function statusLabel(s) {
  return { osnutek: 'Osnutek', potrjena: 'Potrjena', poslana: 'Poslana', dokoncana: 'Dokončana', stornirana: 'Stornirana' }[s] || s;
}

// ─── DASHBOARD ───────────────────────────────────────────
async function renderDashboard() {
  const el = document.getElementById('view-dashboard');
  el.innerHTML = `<div class="page-header"><div><div class="page-title">Pregled</div><div class="page-subtitle">Povzetek poslovanja</div></div></div><div class="stats-grid" id="stats"></div><div style="display:grid;grid-template-columns:1fr 1fr;gap:20px"><div class="card"><div class="card-title">📋 Zadnje naročilnice</div><div id="recent-narocilnice"></div></div><div class="card"><div class="card-title">💼 Zadnje ponudbe</div><div id="recent-ponudbe"></div></div></div>`;

  const [narocilnice, ponudbe, stranke] = await Promise.all([
    GET('/narocilnice?tip=narocilnica'),
    GET('/narocilnice?tip=ponudba'),
    GET('/stranke')
  ]);

  const vsotaN = narocilnice.reduce((s, n) => s + (n.vsota_z_ddv || 0), 0);
  document.getElementById('stats').innerHTML = `
    <div class="stat-card"><div class="stat-label">Stranke</div><div class="stat-value orange">${stranke.length}</div></div>
    <div class="stat-card"><div class="stat-label">Naročilnice</div><div class="stat-value blue">${narocilnice.length}</div></div>
    <div class="stat-card"><div class="stat-label">Ponudbe</div><div class="stat-value">${ponudbe.length}</div></div>
    <div class="stat-card"><div class="stat-label">Promet (z DDV)</div><div class="stat-value green">${fmtEur(vsotaN)}</div></div>
  `;

  const mkRecent = (list, el) => {
    if (!list.length) { document.getElementById(el).innerHTML = '<div style="color:#4b5563;font-size:.85rem;padding:10px 0">Ni zapisov</div>'; return; }
    document.getElementById(el).innerHTML = '<div class="recent-list">' + list.slice(0, 6).map(n => `
      <div class="recent-item" onclick="openNarocilnicaDetail(${n.id})">
        <div class="recent-item-left">
          <div class="recent-item-num">${n.stevilka}</div>
          <div class="recent-item-sub">${n.podjetje || `${n.ime} ${n.priimek || ''}`.trim()}${n.marka ? ` · ${n.marka} ${n.model}` : ''}</div>
        </div>
        <div class="recent-item-right">
          <div class="recent-item-amount">${fmtEur(n.vsota_z_ddv)}</div>
          <div class="recent-item-date">${fmtDate(n.created_at)} ${statusBadge(n.status)}</div>
        </div>
      </div>`).join('') + '</div>';
  };
  mkRecent(narocilnice, 'recent-narocilnice');
  mkRecent(ponudbe, 'recent-ponudbe');
}

// ─── NAROCILNICE / PONUDBE LIST ───────────────────────────
async function renderListView(tip) {
  const id = tip === 'narocilnica' ? 'narocilnice' : 'ponudbe';
  const tipLabel = tip === 'narocilnica' ? 'Naročilnice' : 'Ponudbe';
  const el = document.getElementById('view-' + id);
  el.innerHTML = `
    <div class="page-header">
      <div><div class="page-title">${tipLabel}</div><div class="page-subtitle" id="${id}-count"></div></div>
      <button class="btn btn-primary" onclick="openNovaNarocilnica('${tip}')">+ Nova ${tip === 'narocilnica' ? 'naročilnica' : 'ponudba'}</button>
    </div>
    <div class="search-bar">
      <input class="search-input" placeholder="Išči po številki, stranki..." oninput="searchNarocilnice(this.value,'${tip}')" id="search-${id}">
    </div>
    <div class="filter-tabs" id="tabs-${id}">
      <button class="filter-tab active" onclick="filterNarocilnice('',this,'${tip}')">Vse</button>
      <button class="filter-tab" onclick="filterNarocilnice('osnutek',this,'${tip}')">Osnutek</button>
      <button class="filter-tab" onclick="filterNarocilnice('potrjena',this,'${tip}')">Potrjena</button>
      <button class="filter-tab" onclick="filterNarocilnice('poslana',this,'${tip}')">Poslana</button>
      <button class="filter-tab" onclick="filterNarocilnice('dokoncana',this,'${tip}')">Dokončana</button>
    </div>
    <div class="table-wrap">
      <table id="table-${id}">
        <thead><tr>
          <th>Številka</th><th>Stranka</th><th>Vozilo</th>
          <th>Postavk</th><th>Vrednost (z DDV)</th>
          <th>Datum</th><th>Status</th><th></th>
        </tr></thead>
        <tbody id="tbody-${id}"></tbody>
      </table>
    </div>`;
  await loadNarocilniceTable('', '', tip);
}

let narocilnicaCurrentFilter = '';
let narocilnicaCurrentSearch = '';

async function loadNarocilniceTable(search, status, tip) {
  const id = tip === 'narocilnica' ? 'narocilnice' : 'ponudbe';
  let url = `/narocilnice?tip=${tip}`;
  if (search) url += `&q=${encodeURIComponent(search)}`;
  if (status) url += `&status=${status}`;
  const data = await GET(url);
  const el = document.getElementById(`tbody-${id}`);
  const countEl = document.getElementById(`${id}-count`);
  if (countEl) countEl.textContent = `${data.length} zapisov`;
  if (!data.length) { el.innerHTML = `<tr><td colspan="8" class="table-empty">Ni rezultatov</td></tr>`; return; }
  el.innerHTML = data.map(n => `
    <tr onclick="openNarocilnicaDetail(${n.id})">
      <td class="bold">${n.stevilka}</td>
      <td>${n.podjetje || `${n.ime} ${n.priimek || ''}`.trim()}<br><small style="color:#4b5563">${n.stranka_sifra}</small></td>
      <td>${n.marka ? `${n.marka} ${n.model}${n.letnik ? ` '${String(n.letnik).slice(2)}` : ''}${n.registrska ? `<br><small style="color:#4b5563">${n.registrska}</small>` : ''}` : '<span style="color:#4b5563">—</span>'}</td>
      <td style="text-align:center">${n.st_postavk}</td>
      <td class="bold">${fmtEur(n.vsota_z_ddv)}</td>
      <td>${fmtDate(n.created_at)}</td>
      <td>${statusBadge(n.status)}</td>
      <td onclick="event.stopPropagation()">
        <button class="btn-icon" title="PDF" onclick="openPdf(${n.id})">🖨️</button>
        <button class="btn-icon" title="Uredi" onclick="openNarocilnicaDetail(${n.id})">✏️</button>
        <button class="btn-icon" title="Izbriši" onclick="deleteNarocilnica(${n.id},'${tip}')">🗑️</button>
      </td>
    </tr>`).join('');
}

function searchNarocilnice(val, tip) {
  clearTimeout(searchTimeout);
  searchTimeout = setTimeout(() => loadNarocilniceTable(val, narocilnicaCurrentFilter, tip), 250);
}
function filterNarocilnice(status, btn, tip) {
  narocilnicaCurrentFilter = status;
  document.querySelectorAll(`#tabs-${tip === 'narocilnica' ? 'narocilnice' : 'ponudbe'} .filter-tab`).forEach(b => b.classList.remove('active'));
  btn.classList.add('active');
  const searchEl = document.getElementById(`search-${tip === 'narocilnica' ? 'narocilnice' : 'ponudbe'}`);
  loadNarocilniceTable(searchEl?.value || '', status, tip);
}
async function deleteNarocilnica(id, tip) {
  if (!confirm('Res izbrisati?')) return;
  const r = await DEL(`/narocilnice/${id}`);
  if (r.ok) { toast('Izbrisano', 'success'); loadNarocilniceTable('', narocilnicaCurrentFilter, tip); }
}
function openPdf(id) { window.open(`/api/pdf/${id}`, '_blank'); }

// ─── NOVA NAROČILNICA ─────────────────────────────────────
async function openNovaNarocilnica(tip) {
  const stranke = await GET('/stranke');
  openModal(`
    <div class="modal-title">+ Nova ${tip === 'narocilnica' ? 'naročilnica' : 'ponudba'}</div>
    <div class="form-grid">
      <div class="form-group form-full">
        <label>Stranka *</label>
        <input id="nn-search" placeholder="Ime, priimek, podjetje, šifra..." oninput="filterStrankeDropdown(this.value)" autocomplete="off">
        <input type="hidden" id="nn-stranka-id">
        <div id="nn-dropdown" style="position:relative"></div>
      </div>
      <div id="nn-vozila-wrap" class="form-full" style="display:none">
        <div class="section-title">Vozilo (izbirno)</div>
        <div id="nn-vozila-list"></div>
        <button class="btn btn-secondary btn-sm" style="margin-top:8px" onclick="openNovoVoziloInline()">+ Novo vozilo</button>
      </div>
      <div class="form-group form-full">
        <label>Opomba</label>
        <textarea id="nn-opomba" rows="2"></textarea>
      </div>
    </div>
    <div class="modal-actions">
      <button class="btn btn-secondary" onclick="closeModal()">Prekliči</button>
      <button class="btn btn-primary" onclick="createNarocilnica('${tip}')">Ustvari →</button>
    </div>
    <script>
      window._stranke = ${JSON.stringify(stranke)};
      window._selStrankaId = null;
      window._selVoziloId = null;
    </script>
  `);
}

function filterStrankeDropdown(q) {
  const list = window._stranke.filter(s => {
    const t = q.toLowerCase();
    return s.sifra.toLowerCase().includes(t) || s.ime.toLowerCase().includes(t) ||
      (s.priimek||'').toLowerCase().includes(t) || (s.podjetje||'').toLowerCase().includes(t) ||
      (s.telefon||'').includes(t);
  }).slice(0, 8);
  const dd = document.getElementById('nn-dropdown');
  if (!list.length || !q) { dd.innerHTML = ''; return; }
  dd.innerHTML = `<div style="background:#0f1117;border:1px solid #2a2d3e;border-radius:8px;margin-top:4px;overflow:hidden">` +
    list.map(s => `<div onclick="selectStranka(${s.id})" style="padding:10px 14px;cursor:pointer;border-bottom:1px solid #1e2130" onmouseover="this.style.background='#1a1d27'" onmouseout="this.style.background=''">
      <strong style="color:#fff">${s.podjetje || `${s.ime} ${s.priimek||''}`.trim()}</strong>
      <span style="color:#6b7280;font-size:.8rem;margin-left:8px">${s.sifra}</span>
      ${s.telefon ? `<span style="color:#4b5563;font-size:.75rem;margin-left:8px">📞 ${s.telefon}</span>` : ''}
    </div>`).join('') + '</div>';
}

async function selectStranka(id) {
  window._selStrankaId = id;
  const s = window._stranke.find(x => x.id === id);
  document.getElementById('nn-search').value = s.podjetje || `${s.ime} ${s.priimek||''}`.trim();
  document.getElementById('nn-stranka-id').value = id;
  document.getElementById('nn-dropdown').innerHTML = '';
  // Load vozila
  const vozila = await GET(`/vozila/stranka/${id}`);
  const wrap = document.getElementById('nn-vozila-wrap');
  wrap.style.display = 'block';
  const listEl = document.getElementById('nn-vozila-list');
  if (!vozila.length) { listEl.innerHTML = '<div style="color:#4b5563;font-size:.82rem">Ni vozil za to stranko</div>'; return; }
  listEl.innerHTML = vozila.map(v => `
    <div class="vozilo-card" id="vc-${v.id}" onclick="selectVozilo(${v.id})">
      <div>
        <div class="vozilo-card-title">${v.marka} ${v.model}${v.letnik ? ` (${v.letnik})` : ''}</div>
        <div class="vozilo-card-sub">${[v.registrska, v.vin ? `VIN: ${v.vin}` : null, v.tip_motorja].filter(Boolean).join(' · ')}</div>
      </div>
      <span style="color:#4b5563">○</span>
    </div>`).join('');
}

function selectVozilo(id) {
  window._selVoziloId = window._selVoziloId === id ? null : id;
  document.querySelectorAll('.vozilo-card').forEach(c => {
    c.classList.toggle('selected', c.id === 'vc-' + id && window._selVoziloId === id);
    c.querySelector('span').textContent = c.id === 'vc-' + id && window._selVoziloId === id ? '●' : '○';
  });
}

async function createNarocilnica(tip) {
  const sid = window._selStrankaId || parseInt(document.getElementById('nn-stranka-id').value);
  if (!sid) { toast('Izberi stranko!', 'error'); return; }
  const r = await POST('/narocilnice', {
    stranka_id: sid,
    vozilo_id: window._selVoziloId || null,
    tip,
    opomba: document.getElementById('nn-opomba').value
  });
  if (r.ok) {
    closeModal();
    toast(`Ustvarjeno: ${r.stevilka}`, 'success');
    await openNarocilnicaDetail(r.id);
  } else toast(r.error || 'Napaka', 'error');
}

// ─── NAROČILNICA DETAIL ───────────────────────────────────
async function openNarocilnicaDetail(id) {
  const n = await GET(`/narocilnice/${id}`);
  if (!n) return;
  const strankaIme = n.podjetje || `${n.ime} ${n.priimek || ''}`.trim();
  const tipLabel = n.tip === 'ponudba' ? 'Ponudba' : 'Naročilnica';

  openModal(`
    <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:18px">
      <div>
        <div class="modal-title" style="margin-bottom:4px">${tipLabel}: ${n.stevilka}</div>
        <div style="color:#6b7280;font-size:.82rem">${strankaIme}${n.marka ? ` · ${n.marka} ${n.model}` : ''}</div>
      </div>
      <div style="display:flex;gap:8px;align-items:center">
        ${statusBadge(n.status)}
        <button class="btn btn-secondary btn-sm" onclick="openPdf(${n.id})">🖨️ PDF</button>
        ${n.tip === 'ponudba' ? `<button class="btn btn-primary btn-sm" onclick="konvertirajPonudbo(${n.id})">→ Naročilnica</button>` : ''}
      </div>
    </div>

    <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:10px 18px;margin-bottom:18px">
      <div>
        <label>Status</label>
        <select id="det-status" style="margin-top:4px">
          <option value="osnutek" ${n.status==='osnutek'?'selected':''}>Osnutek</option>
          <option value="potrjena" ${n.status==='potrjena'?'selected':''}>Potrjena</option>
          <option value="poslana" ${n.status==='poslana'?'selected':''}>Poslana</option>
          <option value="dokoncana" ${n.status==='dokoncana'?'selected':''}>Dokončana</option>
          <option value="stornirana" ${n.status==='stornirana'?'selected':''}>Stornirana</option>
        </select>
      </div>
      <div>
        <label>Popust %</label>
        <input type="number" id="det-popust" value="${n.popust_procent||0}" min="0" max="100" step="0.5" style="margin-top:4px">
      </div>
      <div style="grid-column:1/-1">
        <label>Opomba</label>
        <textarea id="det-opomba" rows="2" style="margin-top:4px">${n.opomba||''}</textarea>
      </div>
    </div>

    ${n.marka ? `<div class="card" style="margin-bottom:14px;background:#0f1117">
      <div style="display:grid;grid-template-columns:repeat(4,1fr);gap:8px">
        <div><label>Vozilo</label><span style="color:#e2e4ea;font-size:.88rem;display:block;margin-top:2px">${n.marka} ${n.model}${n.letnik ? ` (${n.letnik})` : ''}</span></div>
        ${n.registrska ? `<div><label>Registrska</label><span style="color:#e2e4ea;font-size:.88rem;display:block;margin-top:2px">${n.registrska}</span></div>` : ''}
        ${n.vin ? `<div><label>VIN</label><span style="color:#e2e4ea;font-size:.88rem;display:block;margin-top:2px;font-family:monospace">${n.vin}</span></div>` : ''}
        ${n.ccm ? `<div><label>Motor</label><span style="color:#e2e4ea;font-size:.88rem;display:block;margin-top:2px">${n.ccm}ccm${n.kw ? ` / ${n.kw}kW` : ''}${n.tip_motorja ? ` ${n.tip_motorja}` : ''}</span></div>` : ''}
      </div>
    </div>` : ''}

    <div class="section-title">Artikli / Postavke</div>
    <div id="postavke-editor"></div>
    <button class="btn btn-secondary btn-sm" style="margin-top:8px" onclick="addPostavka()">+ Dodaj artikel</button>

    <div class="modal-actions">
      <button class="btn btn-secondary" onclick="closeModal()">Zapri</button>
      <button class="btn btn-primary" onclick="saveNarocilnicaDetail(${n.id}, '${n.tip}')">💾 Shrani</button>
    </div>
  `, true);

  window._editPostavke = n.postavke ? JSON.parse(JSON.stringify(n.postavke)) : [];
  renderPostavkeEditor();
}

function renderPostavkeEditor() {
  const rows = window._editPostavke;
  document.getElementById('postavke-editor').innerHTML = `
    <table class="postavke-table">
      <thead><tr>
        <th class="col-katalog">Katalog št.</th>
        <th class="col-naziv">Naziv *</th>
        <th class="col-kol">Kol.</th>
        <th class="col-enota">Enota</th>
        <th class="col-cena">Cena brez DDV</th>
        <th class="col-ddv">DDV %</th>
        <th class="col-popust">Pop. %</th>
        <th class="col-skupaj">Skupaj</th>
        <th class="col-del"></th>
      </tr></thead>
      <tbody>${rows.map((p, i) => postavkaRow(p, i)).join('')}</tbody>
    </table>
    <div class="postavke-totals">${calcTotalsHtml()}</div>`;
}

function postavkaRow(p, i) {
  const skupaj = (p.kolicina||1) * (p.cena_brez_ddv||0) * (1-(p.popust_procent||0)/100);
  return `<tr>
    <td class="col-katalog"><input value="${p.katalog_st||''}" oninput="updatePostavka(${i},'katalog_st',this.value)" placeholder="—"></td>
    <td class="col-naziv"><input value="${p.naziv||''}" oninput="updatePostavka(${i},'naziv',this.value)" placeholder="Naziv artikla *" required></td>
    <td class="col-kol"><input type="number" value="${p.kolicina||1}" min="0.01" step="0.01" oninput="updatePostavka(${i},'kolicina',+this.value)"></td>
    <td class="col-enota">
      <select oninput="updatePostavka(${i},'enota',this.value)">
        ${['kos','kom','l','kg','m','set','par'].map(e => `<option ${p.enota===e?'selected':''}>${e}</option>`).join('')}
      </select>
    </td>
    <td class="col-cena"><input type="number" value="${p.cena_brez_ddv||0}" min="0" step="0.01" oninput="updatePostavka(${i},'cena_brez_ddv',+this.value)"></td>
    <td class="col-ddv">
      <select oninput="updatePostavka(${i},'ddv_procent',+this.value)">
        ${[0,9.5,22].map(d => `<option value="${d}" ${p.ddv_procent==d?'selected':''}>${d}%</option>`).join('')}
      </select>
    </td>
    <td class="col-popust"><input type="number" value="${p.popust_procent||0}" min="0" max="100" step="0.5" oninput="updatePostavka(${i},'popust_procent',+this.value)"></td>
    <td class="col-skupaj">${skupaj.toFixed(2)} €</td>
    <td class="col-del"><button class="btn-icon" onclick="removePostavka(${i})">✕</button></td>
  </tr>`;
}

function calcTotalsHtml() {
  let brezDdv = 0, ddvZnesek = 0;
  for (const p of window._editPostavke) {
    const b = (p.kolicina||1) * (p.cena_brez_ddv||0) * (1-(p.popust_procent||0)/100);
    brezDdv += b;
    ddvZnesek += b * ((p.ddv_procent||22)/100);
  }
  return `Brez DDV: <strong>${brezDdv.toFixed(2)} €</strong> &nbsp;|&nbsp; DDV: <strong>${ddvZnesek.toFixed(2)} €</strong> &nbsp;|&nbsp; <span class="total-final">Skupaj: ${(brezDdv+ddvZnesek).toFixed(2)} €</span>`;
}

function updatePostavka(i, key, val) {
  window._editPostavke[i][key] = val;
  // Refresh just totals & that row's skupaj cell
  document.querySelectorAll('.postavke-table tbody tr')[i].cells[7].textContent =
    ((window._editPostavke[i].kolicina||1) * (window._editPostavke[i].cena_brez_ddv||0) * (1-(window._editPostavke[i].popust_procent||0)/100)).toFixed(2) + ' €';
  document.querySelector('.postavke-totals').innerHTML = calcTotalsHtml();
}

function addPostavka() {
  window._editPostavke.push({ katalog_st:'', naziv:'', kolicina:1, enota:'kos', cena_brez_ddv:0, ddv_procent:22, popust_procent:0 });
  renderPostavkeEditor();
  // Focus last naziv input
  const rows = document.querySelectorAll('.postavke-table tbody tr');
  if (rows.length) rows[rows.length-1].querySelectorAll('input')[1]?.focus();
}

function removePostavka(i) {
  window._editPostavke.splice(i, 1);
  renderPostavkeEditor();
}

async function saveNarocilnicaDetail(id, tip) {
  // Validate
  for (const p of window._editPostavke) {
    if (!p.naziv?.trim()) { toast('Vsak artikel mora imeti naziv!', 'error'); return; }
  }
  const header = {
    status: document.getElementById('det-status').value,
    opomba: document.getElementById('det-opomba').value,
    popust_procent: parseFloat(document.getElementById('det-popust').value) || 0
  };
  await PUT(`/narocilnice/${id}`, header);
  await PUT(`/narocilnice/${id}/postavke`, { postavke: window._editPostavke });
  toast('Shranjeno ✓', 'success');
  closeModal();
  renderView(currentView);
}

async function konvertirajPonudbo(id) {
  if (!confirm('Pretvoriti ponudbo v naročilnico?')) return;
  const r = await POST(`/narocilnice/${id}/konvertiraj`);
  if (r.ok) { toast(`Naročilnica: ${r.stevilka}`, 'success'); closeModal(); renderView(currentView); }
  else toast(r.error, 'error');
}

// ─── STRANKE ─────────────────────────────────────────────
async function renderStranke() {
  const el = document.getElementById('view-stranke');
  el.innerHTML = `
    <div class="page-header">
      <div><div class="page-title">Kartoteka strank</div><div class="page-subtitle" id="stranke-count"></div></div>
      <button class="btn btn-primary" onclick="openNovaStranka()">+ Nova stranka</button>
    </div>
    <div class="search-bar">
      <input class="search-input" placeholder="Išči po šifri, imenu, podjetju, telefonu..." oninput="searchStranke(this.value)">
    </div>
    <div class="table-wrap">
      <table>
        <thead><tr><th>Šifra</th><th>Ime / Podjetje</th><th>Telefon</th><th>Email</th><th>Vozil</th><th>Naroč.</th><th></th></tr></thead>
        <tbody id="tbody-stranke"></tbody>
      </table>
    </div>`;
  loadStrankeTable('');
}

async function loadStrankeTable(q) {
  const data = await GET(`/stranke${q ? '?q='+encodeURIComponent(q) : ''}`);
  const countEl = document.getElementById('stranke-count');
  if (countEl) countEl.textContent = `${data.length} strank`;
  const tbody = document.getElementById('tbody-stranke');
  if (!data.length) { tbody.innerHTML = `<tr><td colspan="7" class="table-empty">Ni strank</td></tr>`; return; }
  tbody.innerHTML = data.map(s => `
    <tr onclick="openStrankaDetail(${s.id})">
      <td class="bold" style="font-family:monospace">${s.sifra}</td>
      <td>
        <div style="color:#fff;font-weight:600">${s.podjetje || `${s.ime} ${s.priimek||''}`.trim()}</div>
        ${s.podjetje && s.ime ? `<div style="font-size:.75rem;color:#6b7280">${s.ime} ${s.priimek||''}</div>` : ''}
      </td>
      <td>${s.telefon || '—'}</td>
      <td>${s.email || '—'}</td>
      <td style="text-align:center">${s.st_vozil}</td>
      <td style="text-align:center">${s.st_narocilnic}</td>
      <td onclick="event.stopPropagation()">
        <button class="btn-icon" onclick="openStrankaDetail(${s.id})">✏️</button>
        <button class="btn-icon" onclick="deleteStranka(${s.id})">🗑️</button>
      </td>
    </tr>`).join('');
}

function searchStranke(v) {
  clearTimeout(searchTimeout);
  searchTimeout = setTimeout(() => loadStrankeTable(v), 250);
}

async function openNovaStranka() {
  const next = await GET('/stranke/meta/next-sifra');
  openModal(`
    <div class="modal-title">+ Nova stranka</div>
    <div class="form-grid cols3">
      <div class="form-group">
        <label>Šifra *</label>
        <input id="ns-sifra" value="${next.sifra}" required>
      </div>
      <div class="form-group">
        <label>Ime *</label>
        <input id="ns-ime" required>
      </div>
      <div class="form-group">
        <label>Priimek</label>
        <input id="ns-priimek">
      </div>
      <div class="form-group form-full">
        <label>Podjetje</label>
        <input id="ns-podjetje">
      </div>
      <div class="form-group">
        <label>Telefon</label>
        <input id="ns-telefon" type="tel">
      </div>
      <div class="form-group">
        <label>Email</label>
        <input id="ns-email" type="email">
      </div>
      <div class="form-group form-full">
        <label>Naslov</label>
        <input id="ns-naslov">
      </div>
      <div class="form-group form-full">
        <label>Opomba</label>
        <textarea id="ns-opomba" rows="2"></textarea>
      </div>
    </div>
    <div class="modal-actions">
      <button class="btn btn-secondary" onclick="closeModal()">Prekliči</button>
      <button class="btn btn-primary" onclick="saveNovaStranka()">Shrani →</button>
    </div>
  `);
  document.getElementById('ns-ime').focus();
}

async function saveNovaStranka() {
  const r = await POST('/stranke', {
    sifra: document.getElementById('ns-sifra').value.trim(),
    ime: document.getElementById('ns-ime').value.trim(),
    priimek: document.getElementById('ns-priimek').value.trim(),
    podjetje: document.getElementById('ns-podjetje').value.trim(),
    telefon: document.getElementById('ns-telefon').value.trim(),
    email: document.getElementById('ns-email').value.trim(),
    naslov: document.getElementById('ns-naslov').value.trim(),
    opomba: document.getElementById('ns-opomba').value.trim()
  });
  if (r.ok) { closeModal(); toast('Stranka dodana ✓', 'success'); loadStrankeTable(''); }
  else toast(r.error || 'Napaka', 'error');
}

async function openStrankaDetail(id) {
  const s = await GET(`/stranke/${id}`);
  openModal(`
    <div class="modal-title">Stranka: ${s.sifra}</div>
    <div class="form-grid cols3">
      <div class="form-group">
        <label>Šifra</label>
        <input value="${s.sifra}" disabled style="opacity:.5">
      </div>
      <div class="form-group">
        <label>Ime *</label>
        <input id="es-ime" value="${s.ime||''}">
      </div>
      <div class="form-group">
        <label>Priimek</label>
        <input id="es-priimek" value="${s.priimek||''}">
      </div>
      <div class="form-group form-full">
        <label>Podjetje</label>
        <input id="es-podjetje" value="${s.podjetje||''}">
      </div>
      <div class="form-group">
        <label>Telefon</label>
        <input id="es-telefon" value="${s.telefon||''}">
      </div>
      <div class="form-group">
        <label>Email</label>
        <input id="es-email" value="${s.email||''}">
      </div>
      <div class="form-group form-full">
        <label>Naslov</label>
        <input id="es-naslov" value="${s.naslov||''}">
      </div>
      <div class="form-group form-full">
        <label>Opomba</label>
        <textarea id="es-opomba" rows="2">${s.opomba||''}</textarea>
      </div>
    </div>

    <div class="section-title">🚗 Vozila (${s.vozila.length})</div>
    <div style="display:flex;flex-direction:column;gap:6px;margin-bottom:10px">
      ${s.vozila.map(v => `
        <div class="vozilo-card" style="cursor:default">
          <div>
            <div class="vozilo-card-title">${v.marka} ${v.model}${v.letnik ? ` (${v.letnik})` : ''}</div>
            <div class="vozilo-card-sub">${[v.registrska, v.vin ? `VIN: ${v.vin}` : null, v.ccm ? `${v.ccm}ccm` : null, v.kw ? `${v.kw}kW` : null].filter(Boolean).join(' · ')}</div>
          </div>
          <div style="display:flex;gap:6px">
            <button class="btn-icon" onclick="openUrediVozilo(${v.id},${s.id})">✏️</button>
            <button class="btn-icon" onclick="deleteVozilo(${v.id},${s.id})">🗑️</button>
          </div>
        </div>`).join('')}
    </div>
    <button class="btn btn-secondary btn-sm" onclick="openNovVideoForStranka(${s.id})">+ Dodaj vozilo</button>

    ${s.narocilnice.length ? `
    <div class="section-title">📋 Naročilnice & ponudbe (${s.narocilnice.length})</div>
    <div style="display:flex;flex-direction:column;gap:5px">
      ${s.narocilnice.slice(0,8).map(n => `
        <div class="recent-item" onclick="closeModal();openNarocilnicaDetail(${n.id})">
          <div class="recent-item-left">
            <div class="recent-item-num">${n.stevilka} ${n.tip==='ponudba' ? '<span class="badge badge-ponudba">Ponudba</span>' : ''}</div>
            <div class="recent-item-sub">${n.marka ? `${n.marka} ${n.model}` : 'Brez vozila'} · ${n.st_postavk} postavk</div>
          </div>
          <div class="recent-item-right">
            <div class="recent-item-amount">${fmtEur(n.vsota_brez_ddv + n.vsota_brez_ddv * 0.22)}</div>
            <div>${statusBadge(n.status)}</div>
          </div>
        </div>`).join('')}
    </div>` : ''}

    <div class="modal-actions">
      <button class="btn btn-secondary" onclick="closeModal()">Zapri</button>
      <button class="btn btn-primary" onclick="saveStranka(${s.id})">💾 Shrani</button>
    </div>
  `, true);
}

async function saveStranka(id) {
  const r = await PUT(`/stranke/${id}`, {
    ime: document.getElementById('es-ime').value,
    priimek: document.getElementById('es-priimek').value,
    podjetje: document.getElementById('es-podjetje').value,
    telefon: document.getElementById('es-telefon').value,
    email: document.getElementById('es-email').value,
    naslov: document.getElementById('es-naslov').value,
    opomba: document.getElementById('es-opomba').value
  });
  if (r.ok) { closeModal(); toast('Shranjeno ✓', 'success'); loadStrankeTable(''); }
  else toast(r.error, 'error');
}

async function deleteStranka(id) {
  if (!confirm('Izbrisati stranko in vse njene podatke?')) return;
  const r = await DEL(`/stranke/${id}`);
  if (r.ok) { toast('Stranka izbrisana', 'success'); loadStrankeTable(''); }
}

// ─── VOZILA FORMS ─────────────────────────────────────────
function voziloForm(v = {}, strankaId) {
  return `
    <div class="form-grid cols3">
      <div class="form-group"><label>Marka *</label><input id="vf-marka" value="${v.marka||''}" required></div>
      <div class="form-group"><label>Model *</label><input id="vf-model" value="${v.model||''}" required></div>
      <div class="form-group"><label>Letnik</label><input id="vf-letnik" type="number" value="${v.letnik||''}" min="1950" max="2030"></div>
      <div class="form-group"><label>Registrska</label><input id="vf-reg" value="${v.registrska||''}"></div>
      <div class="form-group form-full"><label>VIN</label><input id="vf-vin" value="${v.vin||''}" style="font-family:monospace"></div>
      <div class="form-group"><label>Tip motorja</label>
        <select id="vf-tip"><option value="">—</option>${['Bencin','Diesel','Hibrid','Električni','LPG','CNG'].map(t=>`<option ${v.tip_motorja===t?'selected':''}>${t}</option>`).join('')}</select>
      </div>
      <div class="form-group"><label>CCM</label><input id="vf-ccm" type="number" value="${v.ccm||''}"></div>
      <div class="form-group"><label>KW</label><input id="vf-kw" type="number" value="${v.kw||''}"></div>
      <div class="form-group"><label>Km (tek. stanje)</label><input id="vf-km" type="number" value="${v.km||''}"></div>
      <div class="form-group form-full"><label>Opomba</label><textarea id="vf-opomba" rows="2">${v.opomba||''}</textarea></div>
    </div>`;
}

async function openNovVideoForStranka(strankaId) {
  closeModal();
  openModal(`
    <div class="modal-title">+ Novo vozilo</div>
    ${voziloForm({}, strankaId)}
    <div class="modal-actions">
      <button class="btn btn-secondary" onclick="openStrankaDetail(${strankaId})">← Nazaj</button>
      <button class="btn btn-primary" onclick="saveNovoVozilo(${strankaId})">Shrani →</button>
    </div>
  `);
}

async function saveNovoVozilo(strankaId) {
  const r = await POST('/vozila', {
    stranka_id: strankaId,
    marka: document.getElementById('vf-marka').value.trim(),
    model: document.getElementById('vf-model').value.trim(),
    letnik: document.getElementById('vf-letnik').value || null,
    registrska: document.getElementById('vf-reg').value.trim(),
    vin: document.getElementById('vf-vin').value.trim(),
    tip_motorja: document.getElementById('vf-tip').value,
    ccm: document.getElementById('vf-ccm').value || null,
    kw: document.getElementById('vf-kw').value || null,
    km: document.getElementById('vf-km').value || null,
    opomba: document.getElementById('vf-opomba').value
  });
  if (r.ok) { toast('Vozilo dodano ✓', 'success'); openStrankaDetail(strankaId); }
  else toast(r.error || 'Napaka', 'error');
}

async function openUrediVozilo(voziloId, strankaId) {
  const v = await GET(`/vozila/${voziloId}`);
  closeModal();
  openModal(`
    <div class="modal-title">Uredi vozilo</div>
    ${voziloForm(v, strankaId)}
    <div class="modal-actions">
      <button class="btn btn-secondary" onclick="openStrankaDetail(${strankaId})">← Nazaj</button>
      <button class="btn btn-primary" onclick="saveUrediVozilo(${voziloId},${strankaId})">Shrani →</button>
    </div>
  `);
}

async function saveUrediVozilo(voziloId, strankaId) {
  const r = await PUT(`/vozila/${voziloId}`, {
    marka: document.getElementById('vf-marka').value.trim(),
    model: document.getElementById('vf-model').value.trim(),
    letnik: document.getElementById('vf-letnik').value || null,
    registrska: document.getElementById('vf-reg').value.trim(),
    vin: document.getElementById('vf-vin').value.trim(),
    tip_motorja: document.getElementById('vf-tip').value,
    ccm: document.getElementById('vf-ccm').value || null,
    kw: document.getElementById('vf-kw').value || null,
    km: document.getElementById('vf-km').value || null,
    opomba: document.getElementById('vf-opomba').value
  });
  if (r.ok) { toast('Shranjeno ✓', 'success'); openStrankaDetail(strankaId); }
  else toast(r.error, 'error');
}

async function deleteVozilo(voziloId, strankaId) {
  if (!confirm('Izbrisati vozilo?')) return;
  await DEL(`/vozila/${voziloId}`);
  toast('Vozilo izbrisano', 'success');
  openStrankaDetail(strankaId);
}

// ─── CHANGE PASSWORD ──────────────────────────────────────
function showChangePassword() {
  openModal(`
    <div class="modal-title">🔑 Sprememba gesla</div>
    <div class="form-grid" style="grid-template-columns:1fr">
      <div class="form-group"><label>Trenutno geslo</label><input type="password" id="cp-cur"></div>
      <div class="form-group"><label>Novo geslo</label><input type="password" id="cp-new"></div>
      <div class="form-group"><label>Potrdi novo geslo</label><input type="password" id="cp-conf"></div>
    </div>
    <div class="modal-actions">
      <button class="btn btn-secondary" onclick="closeModal()">Prekliči</button>
      <button class="btn btn-primary" onclick="changePassword()">Shrani</button>
    </div>
  `);
}

async function changePassword() {
  const cur = document.getElementById('cp-cur').value;
  const nw = document.getElementById('cp-new').value;
  const conf = document.getElementById('cp-conf').value;
  if (nw !== conf) { toast('Gesli se ne ujemata!', 'error'); return; }
  if (nw.length < 6) { toast('Geslo mora biti vsaj 6 znakov', 'error'); return; }
  const r = await fetch('/api/change-password', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({current:cur,newPass:nw}) });
  const d = await r.json();
  if (d.ok) { closeModal(); toast('Geslo spremenjeno ✓', 'success'); }
  else toast(d.error || 'Napaka', 'error');
}

// ─── INIT ─────────────────────────────────────────────────
renderView('dashboard');
