const express = require('express');
const db = require('../db');
const router = express.Router();

// GET all vozila for a stranka
router.get('/stranka/:stranka_id', (req, res) => {
  const vozila = db.prepare('SELECT * FROM vozila WHERE stranka_id = ? ORDER BY marka, model').all(req.params.stranka_id);
  res.json(vozila);
});

// GET single vozilo
router.get('/:id', (req, res) => {
  const vozilo = db.prepare('SELECT * FROM vozila WHERE id = ?').get(req.params.id);
  if (!vozilo) return res.status(404).json({ error: 'Vozilo ne obstaja' });
  res.json(vozilo);
});

// POST create vozilo
router.post('/', (req, res) => {
  const { stranka_id, vin, marka, model, letnik, tip_motorja, ccm, kw, registrska, km, opomba } = req.body;
  if (!stranka_id || !marka || !model) return res.status(400).json({ error: 'Stranka, marka in model so obvezni' });

  const result = db.prepare(`
    INSERT INTO vozila (stranka_id, vin, marka, model, letnik, tip_motorja, ccm, kw, registrska, km, opomba)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `).run(stranka_id, vin || null, marka, model, letnik || null, tip_motorja || null, ccm || null, kw || null, registrska || null, km || null, opomba || null);
  res.json({ ok: true, id: result.lastInsertRowid });
});

// PUT update vozilo
router.put('/:id', (req, res) => {
  const { vin, marka, model, letnik, tip_motorja, ccm, kw, registrska, km, opomba } = req.body;
  db.prepare(`
    UPDATE vozila SET vin=?, marka=?, model=?, letnik=?, tip_motorja=?, ccm=?, kw=?, registrska=?, km=?, opomba=?
    WHERE id=?
  `).run(vin || null, marka, model, letnik || null, tip_motorja || null, ccm || null, kw || null, registrska || null, km || null, opomba || null, req.params.id);
  res.json({ ok: true });
});

// DELETE vozilo
router.delete('/:id', (req, res) => {
  db.prepare('DELETE FROM vozila WHERE id = ?').run(req.params.id);
  res.json({ ok: true });
});

module.exports = router;
