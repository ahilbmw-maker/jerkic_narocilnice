const express = require('express');
const db = require('../db');
const router = express.Router();

// Helper: generate document number e.g. N-2025-0042
function genStevilka(tip) {
  const leto = new Date().getFullYear();
  const prefix = tip === 'ponudba' ? 'P' : 'N';
  const row = db.prepare('SELECT zadnja_stevilka FROM stevilcnik WHERE leto = ? AND tip = ?').get(leto, tip);
  let next = 1;
  if (row) {
    next = row.zadnja_stevilka + 1;
    db.prepare('UPDATE stevilcnik SET zadnja_stevilka = ? WHERE leto = ? AND tip = ?').run(next, leto, tip);
  } else {
    db.prepare('INSERT INTO stevilcnik (leto, tip, zadnja_stevilka) VALUES (?, ?, 1)').run(leto, tip);
  }
  return `${prefix}-${leto}-${String(next).padStart(4, '0')}`;
}

// GET list - with filters
router.get('/', (req, res) => {
  const { stranka_id, tip, status, q } = req.query;
  let where = ['1=1'];
  let params = [];

  if (stranka_id) { where.push('n.stranka_id = ?'); params.push(stranka_id); }
  if (tip) { where.push('n.tip = ?'); params.push(tip); }
  if (status) { where.push('n.status = ?'); params.push(status); }
  if (q) {
    where.push('(n.stevilka LIKE ? OR s.ime LIKE ? OR s.priimek LIKE ? OR s.podjetje LIKE ?)');
    const like = `%${q}%`;
    params.push(like, like, like, like);
  }

  const rows = db.prepare(`
    SELECT n.*,
      s.ime, s.priimek, s.podjetje, s.sifra as stranka_sifra,
      v.marka, v.model, v.registrska, v.letnik,
      (SELECT COUNT(*) FROM postavke p WHERE p.narocilnica_id = n.id) as st_postavk,
      (SELECT COALESCE(SUM(p.kolicina * p.cena_brez_ddv * (1 - p.popust_procent/100)), 0) FROM postavke p WHERE p.narocilnica_id = n.id) as vsota_brez_ddv,
      (SELECT COALESCE(SUM(p.kolicina * p.cena_brez_ddv * (1 - p.popust_procent/100) * (1 + p.ddv_procent/100)), 0) FROM postavke p WHERE p.narocilnica_id = n.id) as vsota_z_ddv
    FROM narocilnice n
    JOIN stranke s ON s.id = n.stranka_id
    LEFT JOIN vozila v ON v.id = n.vozilo_id
    WHERE ${where.join(' AND ')}
    ORDER BY n.created_at DESC
    LIMIT 200
  `).all(...params);
  res.json(rows);
});

// GET single narocilnica with postavke
router.get('/:id', (req, res) => {
  const n = db.prepare(`
    SELECT n.*,
      s.ime, s.priimek, s.podjetje, s.sifra as stranka_sifra, s.telefon, s.email, s.naslov,
      v.marka, v.model, v.registrska, v.letnik, v.vin, v.tip_motorja, v.ccm, v.kw, v.km
    FROM narocilnice n
    JOIN stranke s ON s.id = n.stranka_id
    LEFT JOIN vozila v ON v.id = n.vozilo_id
    WHERE n.id = ?
  `).get(req.params.id);
  if (!n) return res.status(404).json({ error: 'Ne najdem' });

  const postavke = db.prepare('SELECT * FROM postavke WHERE narocilnica_id = ? ORDER BY id').all(n.id);
  res.json({ ...n, postavke });
});

// POST create
router.post('/', (req, res) => {
  const { stranka_id, vozilo_id, tip, opomba, popust_procent, postavke } = req.body;
  if (!stranka_id) return res.status(400).json({ error: 'Stranka je obvezna' });

  const docTip = tip || 'narocilnica';
  const stevilka = genStevilka(docTip);

  const result = db.prepare(`
    INSERT INTO narocilnice (stevilka, stranka_id, vozilo_id, tip, status, opomba, popust_procent)
    VALUES (?, ?, ?, ?, 'osnutek', ?, ?)
  `).run(stevilka, stranka_id, vozilo_id || null, docTip, opomba || null, popust_procent || 0);

  const nId = result.lastInsertRowid;

  if (postavke && postavke.length > 0) {
    const ins = db.prepare('INSERT INTO postavke (narocilnica_id, katalog_st, naziv, kolicina, enota, cena_brez_ddv, ddv_procent, popust_procent) VALUES (?,?,?,?,?,?,?,?)');
    for (const p of postavke) {
      ins.run(nId, p.katalog_st || null, p.naziv, p.kolicina || 1, p.enota || 'kos', p.cena_brez_ddv || 0, p.ddv_procent ?? 22, p.popust_procent || 0);
    }
  }

  res.json({ ok: true, id: nId, stevilka });
});

// PUT update header
router.put('/:id', (req, res) => {
  const { vozilo_id, status, opomba, popust_procent } = req.body;
  db.prepare(`
    UPDATE narocilnice SET vozilo_id=?, status=?, opomba=?, popust_procent=?, updated_at=CURRENT_TIMESTAMP WHERE id=?
  `).run(vozilo_id || null, status, opomba || null, popust_procent || 0, req.params.id);
  res.json({ ok: true });
});

// PUT update postavke (replace all)
router.put('/:id/postavke', (req, res) => {
  const { postavke } = req.body;
  db.prepare('DELETE FROM postavke WHERE narocilnica_id = ?').run(req.params.id);
  if (postavke && postavke.length > 0) {
    const ins = db.prepare('INSERT INTO postavke (narocilnica_id, katalog_st, naziv, kolicina, enota, cena_brez_ddv, ddv_procent, popust_procent) VALUES (?,?,?,?,?,?,?,?)');
    for (const p of postavke) {
      ins.run(req.params.id, p.katalog_st || null, p.naziv, p.kolicina || 1, p.enota || 'kos', p.cena_brez_ddv || 0, p.ddv_procent ?? 22, p.popust_procent || 0);
    }
  }
  db.prepare('UPDATE narocilnice SET updated_at=CURRENT_TIMESTAMP WHERE id=?').run(req.params.id);
  res.json({ ok: true });
});

// DELETE
router.delete('/:id', (req, res) => {
  db.prepare('DELETE FROM narocilnice WHERE id = ?').run(req.params.id);
  res.json({ ok: true });
});

// Convert ponudba -> narocilnica
router.post('/:id/konvertiraj', (req, res) => {
  const n = db.prepare('SELECT * FROM narocilnice WHERE id = ?').get(req.params.id);
  if (!n) return res.status(404).json({ error: 'Ne najdem' });
  if (n.tip !== 'ponudba') return res.status(400).json({ error: 'Ni ponudba' });
  const novaSt = genStevilka('narocilnica');
  db.prepare("UPDATE narocilnice SET tip='narocilnica', stevilka=?, status='potrjena', updated_at=CURRENT_TIMESTAMP WHERE id=?").run(novaSt, n.id);
  res.json({ ok: true, stevilka: novaSt });
});

module.exports = router;
