const express = require('express');
const db = require('../db');
const router = express.Router();

// GET all stranke (with search)
router.get('/', (req, res) => {
  const q = req.query.q ? `%${req.query.q}%` : '%';
  const stranke = db.prepare(`
    SELECT s.*, COUNT(v.id) as st_vozil, COUNT(n.id) as st_narocilnic
    FROM stranke s
    LEFT JOIN vozila v ON v.stranka_id = s.id
    LEFT JOIN narocilnice n ON n.stranka_id = s.id
    WHERE s.sifra LIKE ? OR s.ime LIKE ? OR s.priimek LIKE ? OR s.podjetje LIKE ? OR s.telefon LIKE ?
    GROUP BY s.id
    ORDER BY s.ime
  `).all(q, q, q, q, q);
  res.json(stranke);
});

// GET single stranka with vozila
router.get('/:id', (req, res) => {
  const stranka = db.prepare('SELECT * FROM stranke WHERE id = ?').get(req.params.id);
  if (!stranka) return res.status(404).json({ error: 'Stranka ne obstaja' });
  const vozila = db.prepare('SELECT * FROM vozila WHERE stranka_id = ? ORDER BY marka, model').all(stranka.id);
  const narocilnice = db.prepare(`
    SELECT n.*, v.marka, v.model, v.registrska,
      (SELECT COUNT(*) FROM postavke p WHERE p.narocilnica_id = n.id) as st_postavk,
      (SELECT COALESCE(SUM(p.kolicina * p.cena_brez_ddv * (1 - p.popust_procent/100)), 0) FROM postavke p WHERE p.narocilnica_id = n.id) as vsota_brez_ddv
    FROM narocilnice n
    LEFT JOIN vozila v ON v.id = n.vozilo_id
    WHERE n.stranka_id = ?
    ORDER BY n.created_at DESC
  `).all(stranka.id);
  res.json({ ...stranka, vozila, narocilnice });
});

// POST create stranka
router.post('/', (req, res) => {
  const { sifra, ime, priimek, podjetje, telefon, email, naslov, opomba } = req.body;
  if (!sifra || !ime) return res.status(400).json({ error: 'Šifra in ime sta obvezni' });

  // Auto-generate sifra if empty
  const finalSifra = sifra || generateSifra(ime);

  try {
    const result = db.prepare(`
      INSERT INTO stranke (sifra, ime, priimek, podjetje, telefon, email, naslov, opomba)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    `).run(finalSifra, ime, priimek || null, podjetje || null, telefon || null, email || null, naslov || null, opomba || null);
    res.json({ ok: true, id: result.lastInsertRowid, sifra: finalSifra });
  } catch (e) {
    if (e.message.includes('UNIQUE')) return res.status(409).json({ error: 'Šifra že obstaja' });
    res.status(500).json({ error: e.message });
  }
});

// PUT update stranka
router.put('/:id', (req, res) => {
  const { ime, priimek, podjetje, telefon, email, naslov, opomba } = req.body;
  db.prepare(`
    UPDATE stranke SET ime=?, priimek=?, podjetje=?, telefon=?, email=?, naslov=?, opomba=?, updated_at=CURRENT_TIMESTAMP
    WHERE id=?
  `).run(ime, priimek || null, podjetje || null, telefon || null, email || null, naslov || null, opomba || null, req.params.id);
  res.json({ ok: true });
});

// DELETE stranka
router.delete('/:id', (req, res) => {
  db.prepare('DELETE FROM stranke WHERE id = ?').run(req.params.id);
  res.json({ ok: true });
});

// GET generate next sifra
router.get('/meta/next-sifra', (req, res) => {
  const last = db.prepare("SELECT sifra FROM stranke WHERE sifra GLOB 'S[0-9]*' ORDER BY CAST(SUBSTR(sifra,2) AS INTEGER) DESC LIMIT 1").get();
  if (!last) return res.json({ sifra: 'S0001' });
  const num = parseInt(last.sifra.slice(1)) + 1;
  res.json({ sifra: 'S' + String(num).padStart(4, '0') });
});

function generateSifra(ime) {
  return 'S' + Date.now().toString().slice(-5);
}

module.exports = router;
