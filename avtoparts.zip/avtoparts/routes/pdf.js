const express = require('express');
const PDFDocument = require('pdfkit');
const db = require('../db');
const router = express.Router();

router.get('/:id', (req, res) => {
  const n = db.prepare(`
    SELECT n.*,
      s.ime, s.priimek, s.podjetje, s.sifra as stranka_sifra, s.telefon, s.email, s.naslov,
      v.marka, v.model, v.registrska, v.letnik, v.vin, v.tip_motorja, v.ccm, v.kw
    FROM narocilnice n
    JOIN stranke s ON s.id = n.stranka_id
    LEFT JOIN vozila v ON v.id = n.vozilo_id
    WHERE n.id = ?
  `).get(req.params.id);

  if (!n) return res.status(404).send('Ne najdem dokumenta');

  const postavke = db.prepare('SELECT * FROM postavke WHERE narocilnica_id = ? ORDER BY id').all(n.id);

  const doc = new PDFDocument({ margin: 50, size: 'A4' });
  const filename = `${n.stevilka.replace(/\//g, '-')}.pdf`;
  res.setHeader('Content-Type', 'application/pdf');
  res.setHeader('Content-Disposition', `inline; filename="${filename}"`);
  doc.pipe(res);

  // ─── HEADER ───
  doc.fontSize(22).font('Helvetica-Bold').fillColor('#1a1d27').text('🔧 AvtoDeli', 50, 50);
  doc.fontSize(9).font('Helvetica').fillColor('#6b7280').text('Sistem za naročilnice', 50, 76);

  // Document type badge
  const tipLabel = n.tip === 'ponudba' ? 'PONUDBA' : 'NAROČILNICA';
  const tipColor = n.tip === 'ponudba' ? '#2563eb' : '#e85d26';
  doc.roundedRect(400, 45, 145, 40, 6).fill(tipColor);
  doc.fontSize(13).font('Helvetica-Bold').fillColor('#ffffff').text(tipLabel, 400, 53, { width: 145, align: 'center' });
  doc.fontSize(9).font('Helvetica').fillColor('#ffffff').text(n.stevilka, 400, 69, { width: 145, align: 'center' });

  doc.moveTo(50, 100).lineTo(545, 100).lineWidth(1).strokeColor('#e5e7eb').stroke();

  // ─── INFO SECTION ───
  let y = 115;

  // Stranka
  doc.fontSize(8).font('Helvetica-Bold').fillColor('#9ca3af').text('STRANKA', 50, y);
  y += 13;
  const strankaIme = n.podjetje || `${n.ime} ${n.priimek || ''}`.trim();
  doc.fontSize(11).font('Helvetica-Bold').fillColor('#111827').text(strankaIme, 50, y);
  y += 14;
  if (n.podjetje && n.ime) {
    doc.fontSize(9).font('Helvetica').fillColor('#4b5563').text(`Kontakt: ${n.ime} ${n.priimek || ''}`, 50, y); y += 12;
  }
  if (n.telefon) { doc.fontSize(9).fillColor('#4b5563').text(`Tel: ${n.telefon}`, 50, y); y += 12; }
  if (n.email) { doc.fontSize(9).fillColor('#4b5563').text(`Email: ${n.email}`, 50, y); y += 12; }
  if (n.naslov) { doc.fontSize(9).fillColor('#4b5563').text(n.naslov, 50, y); y += 12; }

  // Datum & status (right side)
  const dateStr = new Date(n.created_at).toLocaleDateString('sl-SI');
  doc.fontSize(8).font('Helvetica-Bold').fillColor('#9ca3af').text('DATUM', 400, 115);
  doc.fontSize(11).font('Helvetica').fillColor('#111827').text(dateStr, 400, 128);
  doc.fontSize(8).font('Helvetica-Bold').fillColor('#9ca3af').text('STATUS', 400, 148);
  const statusMap = { osnutek: 'Osnutek', potrjena: 'Potrjena', poslana: 'Poslana', dokoncana: 'Dokončana', stornirana: 'Stornirana' };
  doc.fontSize(11).font('Helvetica').fillColor('#111827').text(statusMap[n.status] || n.status, 400, 161);

  // ─── VOZILO ───
  if (n.marka) {
    y = Math.max(y, 115) + 8;
    doc.moveTo(50, y).lineTo(545, y).lineWidth(0.5).strokeColor('#e5e7eb').stroke();
    y += 10;
    doc.fontSize(8).font('Helvetica-Bold').fillColor('#9ca3af').text('VOZILO', 50, y);
    y += 13;
    doc.fontSize(10).font('Helvetica-Bold').fillColor('#111827').text(`${n.marka} ${n.model}${n.letnik ? ` (${n.letnik})` : ''}`, 50, y);
    y += 12;
    const vozInfo = [];
    if (n.registrska) vozInfo.push(`Reg: ${n.registrska}`);
    if (n.vin) vozInfo.push(`VIN: ${n.vin}`);
    if (n.ccm) vozInfo.push(`${n.ccm}ccm`);
    if (n.kw) vozInfo.push(`${n.kw}kW`);
    if (n.tip_motorja) vozInfo.push(n.tip_motorja);
    if (vozInfo.length) {
      doc.fontSize(9).font('Helvetica').fillColor('#4b5563').text(vozInfo.join('   ·   '), 50, y);
      y += 12;
    }
  }

  // ─── POSTAVKE TABLE ───
  y += 12;
  doc.moveTo(50, y).lineTo(545, y).lineWidth(1).strokeColor('#111827').stroke();
  y += 6;

  // Table header
  const cols = { st: 50, katalog: 70, naziv: 160, kol: 340, cena: 390, popust: 445, skupaj: 490 };
  doc.fontSize(8).font('Helvetica-Bold').fillColor('#374151');
  doc.text('#', cols.st, y, { width: 15 });
  doc.text('Katalog št.', cols.katalog, y, { width: 85 });
  doc.text('Naziv artikla', cols.naziv, y, { width: 175 });
  doc.text('Kol.', cols.kol, y, { width: 45, align: 'right' });
  doc.text('Cena (€)', cols.cena, y, { width: 50, align: 'right' });
  doc.text('Pop.%', cols.popust, y, { width: 40, align: 'right' });
  doc.text('Skupaj €', cols.skupaj, y, { width: 55, align: 'right' });

  y += 4;
  doc.moveTo(50, y).lineTo(545, y).lineWidth(0.5).strokeColor('#9ca3af').stroke();
  y += 6;

  let vsotaBrezDdv = 0;
  let vsotaDdv = 0;
  let altRow = false;

  for (let i = 0; i < postavke.length; i++) {
    const p = postavke[i];
    const skupajBrezDdv = p.kolicina * p.cena_brez_ddv * (1 - p.popust_procent / 100);
    const ddvZnesek = skupajBrezDdv * (p.ddv_procent / 100);
    vsotaBrezDdv += skupajBrezDdv;
    vsotaDdv += ddvZnesek;

    if (altRow) {
      doc.rect(50, y - 2, 495, 14).fill('#f9fafb');
    }
    altRow = !altRow;

    doc.fontSize(8).font('Helvetica').fillColor('#111827');
    doc.text(String(i + 1), cols.st, y, { width: 15 });
    doc.text(p.katalog_st || '—', cols.katalog, y, { width: 85 });
    doc.text(p.naziv, cols.naziv, y, { width: 175 });
    doc.text(`${p.kolicina} ${p.enota}`, cols.kol, y, { width: 45, align: 'right' });
    doc.text(fmt(p.cena_brez_ddv), cols.cena, y, { width: 50, align: 'right' });
    doc.text(p.popust_procent > 0 ? `${p.popust_procent}%` : '—', cols.popust, y, { width: 40, align: 'right' });
    doc.text(fmt(skupajBrezDdv), cols.skupaj, y, { width: 55, align: 'right' });

    y += 14;
    if (y > 720) { doc.addPage(); y = 50; }
  }

  // ─── TOTALS ───
  doc.moveTo(50, y).lineTo(545, y).lineWidth(0.5).strokeColor('#9ca3af').stroke();
  y += 10;

  const totX = 380;
  doc.fontSize(9).font('Helvetica').fillColor('#4b5563');
  doc.text('Skupaj brez DDV:', totX, y, { width: 120 });
  doc.text(fmt(vsotaBrezDdv) + ' €', totX + 120, y, { width: 45, align: 'right' });
  y += 14;
  doc.text('DDV:', totX, y, { width: 120 });
  doc.text(fmt(vsotaDdv) + ' €', totX + 120, y, { width: 45, align: 'right' });
  y += 4;
  doc.moveTo(totX, y).lineTo(545, y).lineWidth(1).strokeColor('#111827').stroke();
  y += 6;
  doc.fontSize(12).font('Helvetica-Bold').fillColor('#111827');
  doc.text('SKUPAJ Z DDV:', totX, y, { width: 120 });
  doc.text(fmt(vsotaBrezDdv + vsotaDdv) + ' €', totX + 120, y, { width: 45, align: 'right' });

  // ─── OPOMBA ───
  if (n.opomba) {
    y += 28;
    doc.fontSize(8).font('Helvetica-Bold').fillColor('#9ca3af').text('OPOMBA', 50, y);
    y += 12;
    doc.fontSize(9).font('Helvetica').fillColor('#374151').text(n.opomba, 50, y, { width: 300 });
  }

  // ─── FOOTER ───
  doc.fontSize(7).font('Helvetica').fillColor('#9ca3af')
    .text(`Dokument generiran: ${new Date().toLocaleString('sl-SI')}`, 50, 800, { width: 495, align: 'center' });

  doc.end();
});

function fmt(n) {
  return Number(n || 0).toFixed(2);
}

module.exports = router;
