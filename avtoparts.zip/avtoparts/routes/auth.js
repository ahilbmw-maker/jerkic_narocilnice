const express = require('express');
const bcrypt = require('bcryptjs');
const db = require('../db');
const router = express.Router();

router.get('/login', (req, res) => {
  if (req.session?.userId) return res.redirect('/');
  res.send(loginPage(''));
});

router.post('/login', (req, res) => {
  const { username, password } = req.body;
  const user = db.prepare('SELECT * FROM users WHERE username = ?').get(username);
  if (!user || !bcrypt.compareSync(password, user.password_hash)) {
    return res.send(loginPage('Napačno uporabniško ime ali geslo.'));
  }
  req.session.userId = user.id;
  req.session.username = user.username;
  res.redirect('/');
});

router.post('/logout', (req, res) => {
  req.session.destroy();
  res.redirect('/login');
});

router.post('/api/change-password', (req, res) => {
  if (!req.session?.userId) return res.status(401).json({ error: 'Ni prijave' });
  const { current, newPass } = req.body;
  const user = db.prepare('SELECT * FROM users WHERE id = ?').get(req.session.userId);
  if (!bcrypt.compareSync(current, user.password_hash)) {
    return res.json({ ok: false, error: 'Trenutno geslo je napačno' });
  }
  const hash = bcrypt.hashSync(newPass, 10);
  db.prepare('UPDATE users SET password_hash = ? WHERE id = ?').run(hash, user.id);
  res.json({ ok: true });
});

function loginPage(error) {
  return `<!DOCTYPE html>
<html lang="sl">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Prijava — AvtoDeli</title>
<style>
  @import url('https://fonts.googleapis.com/css2?family=Barlow:wght@400;600;700&display=swap');
  *{box-sizing:border-box;margin:0;padding:0}
  body{font-family:'Barlow',sans-serif;background:#0f1117;display:flex;align-items:center;justify-content:center;min-height:100vh}
  .card{background:#1a1d27;border:1px solid #2a2d3e;border-radius:12px;padding:48px 40px;width:100%;max-width:400px}
  .logo{text-align:center;margin-bottom:32px}
  .logo-icon{font-size:2.5rem;margin-bottom:8px}
  .logo h1{color:#fff;font-size:1.4rem;font-weight:700;letter-spacing:.5px}
  .logo p{color:#6b7280;font-size:.85rem;margin-top:4px}
  label{display:block;color:#9ca3af;font-size:.8rem;font-weight:600;letter-spacing:.5px;text-transform:uppercase;margin-bottom:6px}
  input{width:100%;background:#0f1117;border:1px solid #2a2d3e;border-radius:8px;padding:12px 14px;color:#fff;font-size:.95rem;font-family:'Barlow',sans-serif;outline:none;transition:border-color .2s}
  input:focus{border-color:#e85d26}
  .field{margin-bottom:20px}
  .btn{width:100%;background:#e85d26;color:#fff;border:none;border-radius:8px;padding:13px;font-size:1rem;font-weight:700;font-family:'Barlow',sans-serif;cursor:pointer;letter-spacing:.5px;transition:background .2s;margin-top:8px}
  .btn:hover{background:#d44f1a}
  .error{background:#3b1515;border:1px solid #7f1d1d;color:#fca5a5;border-radius:8px;padding:10px 14px;font-size:.85rem;margin-bottom:20px}
</style>
</head>
<body>
<div class="card">
  <div class="logo">
    <div class="logo-icon">🔧</div>
    <h1>AvtoDeli</h1>
    <p>Sistem za naročilnice</p>
  </div>
  ${error ? `<div class="error">⚠️ ${error}</div>` : ''}
  <form method="POST" action="/login">
    <div class="field">
      <label>Uporabniško ime</label>
      <input type="text" name="username" autofocus autocomplete="username" required>
    </div>
    <div class="field">
      <label>Geslo</label>
      <input type="password" name="password" autocomplete="current-password" required>
    </div>
    <button type="submit" class="btn">Prijava →</button>
  </form>
</div>
</body>
</html>`;
}

module.exports = router;
